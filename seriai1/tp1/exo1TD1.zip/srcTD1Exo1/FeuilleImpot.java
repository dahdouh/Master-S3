
public class FeuilleImpot {
	
	int format; 
	FeuilleImpot(int fm){
		format = fm;
	}
	
	void editer(int categorie){
		//TODO Switch l'ensemble des cas des imposables
		
		// penser au refactoring 
	}

}

"Introduce Parameter Object"
Ce refactor essaye de faire des packets d'arguments allant bien ensemble, pour une utilisation plus aisée lors du passage d'arguments.

Ici, temps de début et de fin, pourrais peut être rassemblé? 
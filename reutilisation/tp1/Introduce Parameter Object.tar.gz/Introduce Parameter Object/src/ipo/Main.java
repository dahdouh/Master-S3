package ipo;

import java.sql.Time;

/*Tiré de l'exemple https://refactoring.com/catalog/introduceParameterObject.html*/
public class Main {
	public void MarkAsHolidaysTime(Time start, Time end){
		
	}
	public void MarkAsWorkingTime(Time start, Time end){
		
	}
	public void MarkAsFamilyTime(Time start, Time end){
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

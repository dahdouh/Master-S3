package pd;

public class Student extends Person{
	public Student(){
		super(true);
	}
}

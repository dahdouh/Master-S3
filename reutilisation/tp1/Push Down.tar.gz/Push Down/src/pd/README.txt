"Push Down" 
Ce refactoring cherche à bien délimiter les classes, en ne s'occupant que de leurs propre contexte. 

Ici les comportements de Person s'occupe décrit des comportements de Student, et ne sont du coup pas au bon endroit conceptuellement.
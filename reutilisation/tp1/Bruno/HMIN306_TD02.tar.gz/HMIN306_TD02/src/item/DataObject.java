package item;

public class DataObject {
	public String content ;
	public int size ;
	protected String name;
	
	public void setName(String nameParam) {
		this.name = nameParam;
	};
}

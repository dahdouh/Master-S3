package item;

import java.util.*;

public class Main {
	
	public static void main(String[] a){
		File f = new File("A_file");
		Link l = new Link();
		Symlink s = new Symlink();
		System.out.println("other_test");
	}
}
